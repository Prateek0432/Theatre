package com.example.demo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightRepository;

@SpringBootTest
class SpringBoot1ApplicationTests {
	
	@Autowired
	FlightRepository flightRepository;

	@Test
	void contextLoads() {
		
		Flight theFlight1 = new Flight();
		Flight theFlight2 = new Flight();
		Flight theFlight3 = new Flight();
		
		theFlight1.setFlightNumber(101);
		theFlight1.setAirline("Indian Airline");
		theFlight1.setSourceCity("DELHI");
		theFlight1.setTargetCity("LUCKNOW");
		theFlight1.setFlightArrivalTime(LocalDateTime.of(2022,06,29,12,30));
		theFlight1.setFlightArrivalTime(LocalDateTime.of(2022,06,29,14,45));
		
		theFlight2.setFlightNumber(105);
		theFlight2.setAirline("INDIGO");
		theFlight2.setSourceCity("BOMBAY");
		theFlight2.setTargetCity("LUCKNOW");
		theFlight2.setFlightArrivalTime(LocalDateTime.of(2022,06,29,12,30));
		theFlight2.setFlightArrivalTime(LocalDateTime.of(2022,06,29,14,45));
		
		theFlight3.setFlightNumber(110);
		theFlight3.setAirline("VISTARA");
		theFlight3.setSourceCity("BOMBAY");
		theFlight3.setTargetCity("LUCKNOW");
		theFlight3.setFlightArrivalTime(LocalDateTime.of(2022,06,29,12,30));
		theFlight3.setFlightArrivalTime(LocalDateTime.of(2022,06,29,14,45));
		flightRepository.save(theFlight1);
		flightRepository.save(theFlight2);
		flightRepository.save(theFlight3);
	}
	
	@Test
	void contextLoads2() {
		
		List<Flight> flightList = new ArrayList<Flight>();
		flightList  = (List) flightRepository.findAll();
		for (Flight flight : flightList) {
			System.out.println("flight Number   : "+flight.getFlightNumber());
			System.out.println("flight Name     : "+flight.getAirline());
			System.out.println("flight Source   : "+flight.getSourceCity());
			System.out.println("flight Target   : "+flight.getTargetCity());
			System.out.println("flight Arrival  : "+flight.getFlightDepartureTime());
			System.out.println("flight Departure: "+flight.getFlightArrivalTime());
			System.out.println("------------------------");
		}
	}

}
