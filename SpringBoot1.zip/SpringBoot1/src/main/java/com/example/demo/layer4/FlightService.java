package com.example.demo.layer4;

import com.example.demo.exception.FlightNotFoundException;
import com.example.demo.layer2.Flight;

public interface FlightService {
	public Flight findFlightById(int flightID) throws FlightNotFoundException;
}
