package com.example.demo.layer4;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.stereotype.Service;

import com.example.demo.exception.FlightNotFoundException;
import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepository;
	
	
	@Override
	public Flight findFlightById(int flightID) throws FlightNotFoundException {
		Optional<Flight> flight = flightRepository.findById(flightID);
		
		if(flight.isPresent()) {
			return flight.get();
		}
		else {
			throw new FlightNotFoundException("Flight with this ID "+ "Does not exist!!!");
		}		 
	}

}
