package com.example.demo.exception;

public class FlightNotFoundException extends Exception {
	
	public FlightNotFoundException(String msg) {
		super(msg);
	}

}
