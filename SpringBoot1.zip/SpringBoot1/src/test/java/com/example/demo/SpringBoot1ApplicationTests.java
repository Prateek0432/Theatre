package com.example.demo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightRepository;

@SpringBootTest
class SpringBoot1ApplicationTests {
	
	@Autowired
	FlightRepository flightRepository;

	@Test
	void contextLoads() {
		Flight theFlight = new Flight();
		theFlight.setAirline("AIR INDIA");
		theFlight.setSourceCity("BOMBAY");
		theFlight.setTargetCity("LUCKNOW");
		theFlight.setFlightArrivalTime(LocalDateTime.of(2022,06,29,12,30));
		theFlight.setFlightArrivalTime(LocalDateTime.of(2022,06,29,14,45));
		flightRepository.save(theFlight);
	}
	
	@Test
	void contextLoads2() {
		
		List<Flight> flightList = new ArrayList<Flight>();
		flightList  = (List) flightRepository.findAll();
		for (Flight flight : flightList) {
			System.out.println("flight Number   : "+flight.getFlightNumber());
			System.out.println("flight Name     : "+flight.getAirline());
			System.out.println("flight Source   : "+flight.getSourceCity());
			System.out.println("flight Target   : "+flight.getTargetCity());
			System.out.println("flight Arrival  : "+flight.getFlightDepartureTime());
			System.out.println("flight Departure: "+flight.getFlightArrivalTime());
			System.out.println("------------------------");
		}
	}

}
